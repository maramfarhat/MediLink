from django.contrib import admin
from django.utils import timezone
from django.contrib import messages
from django.shortcuts import redirect
from .models import Medecin
from .forms import MedecinAdminForm
from dossiers.models import Patient


@admin.register(Medecin)
class MedecinAdmin(admin.ModelAdmin):
    form = MedecinAdminForm
    list_display = ('user', 'specialite', 'numero_ordre', 'telephone', 'statut', 'date_inscription', 'date_validation')
    search_fields = ('user__first_name', 'user__last_name', 'user__email', 'specialite', 'numero_ordre', 'telephone')
    list_filter = ('statut', 'date_inscription', 'specialite')
    readonly_fields = ('date_inscription', 'date_validation')
    fieldsets = (
        ('Informations du médecin', {
            'fields': ('nom_medecin',)
        }),
        ('Informations professionnelles', {
            'fields': ('numero_ordre', 'specialite', 'telephone')
        }),
        ('Statut', {
            'fields': ('statut', 'date_inscription', 'date_validation')
        }),
    )
    ordering = ('-date_inscription',)
    date_hierarchy = 'date_inscription'
    
    actions = ['valider_medecins', 'refuser_medecins', 'creer_patient_medecin']
    
    def creer_patient_medecin(self, request, queryset):
        """Action pour créer un patient à partir d'un médecin"""
        count = 0
        for medecin in queryset:
            if medecin.user:
                # Vérifier si le patient existe déjà
                patient_exists = Patient.objects.filter(
                    nom=medecin.user.last_name or '',
                    prenom=medecin.user.first_name or medecin.user.username
                ).exists()
                
                if not patient_exists:
                    # Créer un patient à partir des informations du médecin
                    Patient.objects.create(
                        nom=medecin.user.last_name or medecin.user.username,
                        prenom=medecin.user.first_name or '',
                        date_naissance='1900-01-01',  # Date par défaut, à modifier
                        sexe='M',  # Par défaut, à modifier
                        telephone=medecin.telephone or '',
                        adresse='',
                        numero_carte_identite=f"MED_{medecin.numero_ordre}"
                    )
                    count += 1
        if count > 0:
            self.message_user(request, f'{count} patient(s) créé(s) à partir des médecins sélectionnés.', messages.SUCCESS)
        else:
            self.message_user(request, 'Aucun patient créé (déjà existants ou informations manquantes).', messages.INFO)
    creer_patient_medecin.short_description = "Créer un patient à partir du médecin"
    
    def valider_medecins(self, request, queryset):
        """Action pour valider plusieurs médecins"""
        count = 0
        for medecin in queryset.filter(statut='en_attente'):
            medecin.statut = 'valide'
            medecin.date_validation = timezone.now()
            medecin.save()
            count += 1
        if count > 0:
            self.message_user(request, f'{count} médecin(s) validé(s) avec succès.', messages.SUCCESS)
        else:
            self.message_user(request, 'Aucun médecin en attente sélectionné.', messages.WARNING)
    valider_medecins.short_description = "Valider les médecins sélectionnés"
    
    def refuser_medecins(self, request, queryset):
        """Action pour refuser plusieurs médecins"""
        count = 0
        for medecin in queryset.filter(statut='en_attente'):
            medecin.statut = 'refuse'
            medecin.save()
            count += 1
        if count > 0:
            self.message_user(request, f'{count} médecin(s) refusé(s).', messages.SUCCESS)
        else:
            self.message_user(request, 'Aucun médecin en attente sélectionné.', messages.WARNING)
    refuser_medecins.short_description = "Refuser les médecins sélectionnés"
